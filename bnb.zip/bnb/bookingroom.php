<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a ticket</title>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">

    <script>
        //insert datepicker jQuery

        $(document).ready(function() {
            $.datepicker.setDefaults({
                dateFormat: 'yy-mm-dd'
            });
            $(function() {
                checkin = $("#checkin").datepicker()
                checkout = $("#checkout").datepicker()

                function getDate(element) {
                    var date;
                    try {
                        date = $.datepicker.parseDate(dateFormat, element.value);
                    } catch (error) {
                        date = null;
                    }
                    return date;
                }
            });
        });
    </script>
</head>
<body>
    
<?php
 include "checksession.php";
 checkUser();
 loginStatus(); 
include "config.php"; //load in any variables
$DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);

if (!$DBC) {
    die("Database connection failed: " . mysqli_connect_error());
}


//function to clean input but not validate type and content
function cleanInput($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

if (isset($_POST['submit']) && $_POST['submit'] === 'Book') {
    $room = cleanInput($_POST['room']);
    $customer = cleanInput($_POST['customers']);
    $checkin = cleanInput($_POST['checkin']);
    $checkout = cleanInput($_POST['checkout']);
    $contactnumber = cleanInput($_POST['contactnumber']);
    $bookingextras = cleanInput($_POST['booking_extras']);
    $roomreview = cleanInput($_POST['room_review']);

    $error = 0;
    $msg = "Error: ";

    $in = new DateTime($checkin);
    $out = new DateTime($checkout);

    if ($in >= $out) {
        $error++;
        $msg .= "Check-out date cannot be earlier or equal to check-in date.";
    }

    if ($error === 0) {
        $query = "INSERT INTO booking (roomID, customerID, check_in_date, check_out_date, contactnumber, booking_extras, room_review) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($DBC, $query);

        if (!$stmt) {
            die("SQL Prepare Error: " . mysqli_error($DBC)); // Debug SQL error
        }

        mysqli_stmt_bind_param($stmt, 'iisssss', $room, $customer, $checkin, $checkout, $contactnumber, $bookingextras, $roomreview);

        if (mysqli_stmt_execute($stmt)) {
            echo "<h5>Booking added successfully.</h5>";
        } else {
            echo "<h5>Error: " . mysqli_stmt_error($stmt) . "</h5>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<h5>$msg</h5>";
    }
}




$query = 'SELECT roomID, roomname, description, roomtype, beds FROM room ORDER BY roomID';
$result = mysqli_query($DBC, $query);
$rowcount = mysqli_num_rows($result);

$query1 = 'SELECT customerID, firstname, lastname, email FROM customer ORDER BY customerID';
$result1 = mysqli_query($DBC, $query1);
$rowcount1 = mysqli_num_rows($result1);
?>
<h1>Booking</h1>
    <h2>
        <a href='bookinglisting.php'>[Return to the Booking listing]</a>
        <a href="index.php">[Return to main page]</a>
    </h2>

    <div>

        <form method="POST">
            <div>
                <label for="room">Room:</label>
                <select name="room" id="room">
                <?php
                    if ($rowcount > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $id = $row['roomID']; ?>

                            <option value="<?php echo $row['roomID']; ?>">
                                <?php echo $row['roomname'] . ' '
                                    . $row['description'] . ' '
                                   . $row['roomtype']
                                   . $row['beds']

                                ?>
                            </option>
                    <?php }
                    } else echo "<option>No Room found</option>";
                    mysqli_free_result($result);
                    ?>

                </select>
            </div>


            <br>
            <div>
                <label for="customers">Customers:</label>
                <select name="customers" id="customers">
                    <?php
                    if ($rowcount1 > 0) {
                        while ($row = mysqli_fetch_assoc($result1)) {
                            $id = $row['roomID']; ?>

                            <option value="<?php echo $row['customerID']; ?>">
                                <?php echo $row['customerID'] . ' '
                                    . $row['firstname'] . ' '
                                    . $row['lastname'] . ' - '
                                    . $row['email']

                                ?>
                            </option>
                    <?php }
                    } else echo "<option>No room found</option>";
                    mysqli_free_result($result1);
                    ?>
                </select>
            </div>
            <br>
            <div>
                <label for="checkin">Check_in Date:</label>
                <input type="text" id="checkin" name="checkin" required>
            </div>
            <br>
            <div>
                <label for="checkout">Check_out Date:</label>
                <input type="text" id="checkout" name="checkout" required>
            </div>
            <br>
            <div>
                <label for="contactnumber">Contact Number:</label>
                <input type="text" id="contactnumber" name="contactnumber" required>
            </div>
            <div>
                <label for="booking_extras">Booking Extras:</label>
                <input type="text" id="booking_extras" name="booking_extras" required>
            </div>
            <br>
            <div>
                <label for="room_review">Room Review:</label>
                <input type="text" id="room_review" name="room_review">
            </div>
            <br>
            <div>
                <input type="submit" name="submit" value="Book">
            </div>

        </form>

        <hr>
 

        <h3>Search for Booking</h3>
<div>
    <form id="searchForm" method="get" name="searching">
        <input type="text" id="fromDate" name="fromDate" required placeholder="From Date">
        <input type="text" id="toDate" name="toDate" required placeholder="To Date">
        <input type="submit" value="Search">
    </form>
</div>
<br><br>
<div class="row">
    <table id="tblbookings" border="1">
        <thead>
            <tr>
                <th>booking#</th>
                <th>Room name</th>
                <th>Description</th>
                <th>RoomType</th>              
                <th>Beds</th>              
            </tr>
        </thead>
        <tbody id="result"></tbody> <!-- Display search result here -->
    </table>
</div>

<script>
$(document).ready(function(){
    $("#fromDate").datepicker({dateFormat:"yy-mm-dd"});
    $("#toDate").datepicker({dateFormat:"yy-mm-dd"});

    $("#searchForm").submit(function(event) {
        event.preventDefault(); // Prevent default form submission
        var fromDate = $("#fromDate").val();
        var toDate = $("#toDate").val();
        
        if (fromDate > toDate) {
            alert("From date cannot be later than To date.");
            return false; // Prevents further execution
        }

        searchBooking(); // Call searchTickets function
    });
});

function searchBooking(){
    var fromDate = $("#fromDate").val();
    var toDate = $("#toDate").val();

    $.ajax({
        url: "bookingsearch.php",
        method: "GET",
        data: {fromDate: fromDate, toDate: toDate},
        success: function(response) {
            $("#result").html(response);
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", status, error);
        }
    });
}
</script>
</body>
</html>
