<?php
//MySQL credentails
define("DBUSER","root");
define("DBPASSWORD","root");
define("DBDATABASE","bnb");
?>