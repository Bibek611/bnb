<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse bookings</title>
</head>

<body>

    <?php
    include "checksession.php";
    checkUser();
    loginStatus();



   
    include "config.php";
  
    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);

    if (mysqli_connect_errno()) {
        echo "Error:unable to connect to Mysql." . mysqli_connect_error();
        exit; //stop processing the page further
    }


    //prepare a query and send it to the server
   $query = 'SELECT booking.bookingID, room.roomname, booking.check_in_date, booking.check_out_date, 
   customer.firstname, customer.lastname

   FROM `booking`, room, customer

   WHERE booking.roomID = room.roomID and booking.customerID = customer.customerID
   ORDER BY bookingID';

   $result = mysqli_query($DBC,$query);

   if (!$result) {
    die("Query failed: " . mysqli_error($DBC)); // Debugging step
}
   $rowcount = mysqli_num_rows($result);

    ?>



    <h1>Make a  Booking</h1>
    <h2><a href="bookingroom.php">[Book a room]</a><a href="index.php">[Return to main page]</a></h2>

    <table border="1">
        <thead>
            <tr>
                <th>Current Booking (room, check_in_date, check_out_date)</th>
                <th>Customer</th>
                <th>Action</th>
            </tr>
        </thead>

       
        <?php



if ($rowcount > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $id = $row['bookingID'];

        echo '<tr><td>' . $row['roomname'] . ', ' . $row['check_in_date']
            . ', ' . $row['check_out_date'] . '</td>';

        echo '<td>' . $row['firstname'] . ', ' . $row['lastname'] . '</td>';

        echo     '<td><a href="bookingdetails.php?id=' . $id . '">[view] </a>';
        echo         '<a href="editbooking.php?id=' . $id . '">[edit] </a>';
        echo         '<a href="editseats.php?id=' . $id . '">[room_review] </a>';
        echo         '<a href="deletebooking.php?id=' . $id . '">[delete] </a></td>';
        echo '</tr>' . PHP_EOL;
       

    }
} else echo "<h2>No booking found!</h2>"; 
             




        mysqli_free_result($result);
        mysqli_close($DBC);

        ?>

    </table>



</body>

</html>