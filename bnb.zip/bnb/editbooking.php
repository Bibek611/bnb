<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit booking</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script>
        $(document).ready(function() {
            $.datepicker.setDefaults({
                dateFormat: 'yy-mm-dd'
            });
            $(function() {
                checkin = $("#checkin").datepicker();
                checkout = $("#checkout").datepicker();

                function getDate(element) {
                    var date;
                    try {
                        date = $.datepicker.parseDate(dateFormat, element.value);
                    } catch (error) {
                        date = null;
                    }
                    return date;
                }
            });
        });
    </script>
    


</head>
<?php
    include "checksession.php";
    checkUser();
    loginStatus();
include "config.php";
$DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);
if (mysqli_connect_errno()) {
    echo "Error:Unable to connect to MySQL." . mysqli_connect_error();
    exit;
}

function cleanInput($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

//check if id exists
//retrieve the bookingid from the URL
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET['id'];
    if (empty($id) or !is_numeric($id)) {
        echo "<h2>Invalid booking ID</h2>"; //simple error feedback
        exit;
    } 
}else {
    echo "<h2>No booking ID provided </h2>";
    exit;
}

//on submit check if empty or not string and is submited by POST
if(isset($_POST['submit']) && !empty($_POST['submit']) && ($_POST['submit'] =='Update')){
    
    $room =cleanInput($_POST['room']);
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $contactnumber =cleanInput($_POST['contactnumber']);
    $booking_extras =cleanInput($_POST['booking_extras']);
    $room_review =cleanInput($_POST['room_review']);
    $id =cleanInput($_POST['id']);

    $upd = "UPDATE booking SET roomID =?, check_in_date =?, check_out_date =?,
    contactnumber =?, booking_extras =?, room_review =?
    WHERE bookingID=?";

$stmt = mysqli_prepare($DBC,$upd); //prepare the query
if ($stmt){
    mysqli_stmt_bind_param($stmt,'isssssi', $room, $checkin, $checkout, $contactnumber, $booking_extras,$roomr_eview, $id); 
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);    
    echo "<h2>Booking details updated successfully.</h2>"; 
    } else {
    echo "<h2>Error in preparing the update query.</h2>";
}
}

$query = "SELECT booking.bookingID, room.roomID, room.roomname, room.description,
room.roomtype, room.beds, booking.check_in_date, booking.check_out_date, booking.contactnumber,
booking.booking_extras, booking.room_review FROM booking
INNER JOIN room ON booking.roomID = room.roomID 
WHERE booking.bookingID= ?";


$stmt = mysqli_prepare($DBC, $query);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, 'i', $id); // Bind parameter correctly
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt); // Get result set

    if ($result) {
        $rowcount = mysqli_num_rows($result);
    } else {
        echo "<h2>Error fetching booking details: " . mysqli_error($DBC) . "</h2>";
        exit;
    }
} else {
    echo "<h2>SQL error: " . mysqli_error($DBC) . "</h2>";
    exit;
}

?>

<body>
    <h1>Update booking</h1>
    <h2>
        <a href="bookinglisting.php">[Return to the booking listing]</a>
        <a href="index.php">[Return to main page]</a>
    </h2>
    <div>
        <form action="editbooking.php" method="POST">
            <p>
                <label for="room">Flights:</label>
                <select name="room" id="room">
                    <?php

                    if($rowcount > 0){
                        $row = mysqli_fetch_assoc($result);
                 
                        ?>
                        <option value="<?php echo $row['roomID']; ?>">
                            <?php
                            echo $row['roomname'] ." "
                            .$row['check_in_date'] ." "
                            .$row['check_out_date'] ." "
                            ?>
                        
                        </option>

                    <?php
                     } else echo "<option>No room found!</option>";

                    ?>
                

                </select>
            </p>

            <p>
                <input type="hidden" name="id" value="<?php echo $id;?>" >
            </p>

            <p>
                <label for="checkin">Check-in  Date:</label>
                <input type="text" id="checkin" name="checkin" required 
                value="<?php echo $row['check_in_date'];?>" >
            </p>
            <p>
                <label for="checkout">Check-out Date</label>
                <input type="text" id="checkout" name="checkout" required
                value="<?php echo $row['check_out_date'];?>" >
            </p>
            <p>
                <label for="contactnumber">Contact Number:</label>
                <input type="text" id="contactnumber" name="contactnumber"
                value="<?php echo $row['contactnumber'];?>" >
            </p>
            <p>
                <label for="booking_extras">Booking Extras:</label>
                <input type="text" id="booking_extras" name="booking_extras"
                value="<?php echo $row['booking_extras'];?>" >
            </p>
            <p>
                <label for="room_review">Room Review:</label>
                <input type="text" id="room_review" name="room_review"
                value="<?php echo $row['room_review'];?>" >
            </p>
            <input type="submit" name="submit" value="Update">
        </form>
    </div>

    <?php
    mysqli_free_result($result);
    mysqli_close($DBC);
    ?>
</body>

</html>