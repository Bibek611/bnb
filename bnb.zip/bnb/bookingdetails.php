<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Booking Details</title>
</head>
<body>
    <?php
    include "config.php";
    $DBC = mysqli_connect (DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);

    if (mysqli_connect_errno()) {
        echo "Error: Unable to connect to MySql." .mysqli_connect_error();
        exit; //stop processing the page further
    }

    //retrieve the bookingid from the URL
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET['id'];
    if (empty($id) or !is_numeric($id)) {
        echo "<h2>Invalid booking ID</h2>"; //simple error feedback
        exit;
    } 
}else {
    echo "<h2>No booking ID provided </h2>";
    exit;
}

$query = "SELECT booking.bookingID, room.roomname, room.description,
room.roomtype, room.beds, booking.check_in_date, booking.check_out_date, booking.contactnumber,
booking.booking_extras, booking.room_review FROM `booking`
INNER JOIN `room` ON booking.roomID = room.roomID 
WHERE booking.bookingID= " .$id;


$result = mysqli_query($DBC, $query);
$rowcount = mysqli_num_rows($result);
    ?>

    <!-- We can add a menu bar here to go back -->
<h1>Booking Details View</h1>
<h2><a href="bookinglisting.php">[Return to the booking listing]</a>
<a href="index.php">[Return to the main page]</a>
</h2>

<?php

include "checksession.php";
checkUser();
loginStatus();

if ($rowcount > 0) {
    echo "<fieldset><legend>Booking Detail #$id</legend><dl>";
    $row = mysqli_fetch_assoc($result);

    echo "<dt>Room name: </dt><dd>" . $row['roomname'] . "</dd>" . PHP_EOL;
    echo "<dt> Description: </dt><dd>" . $row['description'] . "</dd>" . PHP_EOL;
    echo "<dt>RoomType: </dt><dd>" . $row['roomtype'] . "</dd>" . PHP_EOL;
    echo "<dt>Beds: </dt><dd>" . $row['beds'] . "</dd>" . PHP_EOL;
    echo "<dt>Check_in Date: </dt><dd>" . $row['check_in_date'] . "</dd>" . PHP_EOL;
    echo "<dt>Check_out Date: </dt><dd>" . $row['check_out_date'] . "</dd>" . PHP_EOL;
    echo "<dt>ContactNumber: </dt><dd>$" . $row['contactnumber'] . "</dd>" . PHP_EOL;
    echo "<dt>Booking_Extras: </dt><dd>" . $row['booking_extras'] . "</dd>" . PHP_EOL;
    echo "<dt>Room_Review: </dt><dd>" . $row['room_review'] . "</dd>" . PHP_EOL;

    echo "</dl></fieldset>" . PHP_EOL;
} else {
    echo "<h5>No Booking found! Possibly deleted!</h5>";
}
mysqli_free_result($result);
mysqli_close($DBC);
?>
</body>
</html>